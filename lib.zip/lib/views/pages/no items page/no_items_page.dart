// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:secondhand/constants/colors.dart';
// import 'package:secondhand/constants/images.dart';
// import 'package:secondhand/utils/size_config.dart';
// import 'package:secondhand/views/pages/bottom%20nav%20bar/home/components/search_item_button.dart';

// class NoItemsPage extends StatelessWidget {
//   const NoItemsPage({Key? key}) : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: 
//     );
//   }
// }
