// import 'package:flutter/material.dart';

// class DPviewer extends StatelessWidget {
//   const DPviewer({Key? key, required this.imageURl}) : super(key: key);
//   final String imageURl;
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.black,
//       appBar: AppBar(
//         elevation: 0,
//         backgroundColor: Colors.black,
        
//       ),
//       body: ,
//     );
//   }
// }
