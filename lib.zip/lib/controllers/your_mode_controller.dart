import 'package:get/get.dart';

class YourModeController extends GetxController {
  var yourModeIndex = 0.obs;
}
