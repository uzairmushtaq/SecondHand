//register or signin page
const String registerSigninImg="assets/images/registerSigninImg.png";
//resgister page img
const String signUpImg="assets/images/Signup.png";

//img for welldone page
const String wellDoneImg="assets/images/Victory.png";

//img for signin
const String signInImg="assets/images/Signin.png";
//post your item ad
const String postYouritemsAD="assets/images/postad.png"; 

//no items in search image
const String noItemImage="assets/images/NoResults.png";

//order and payment method image
const String orderIllustration="assets/images/NoResults.png";

//published item successfully
const String publishItemImage="assets/images/Delivery.png";

//No Data lottie
const String noDataWidget="assets/images/noData.json";