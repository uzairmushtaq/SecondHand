class ConstantFontFamily {
  static String geckoLunch = "Gecko Lunch";
}
