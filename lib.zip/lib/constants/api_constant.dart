String apiURL="https://verwaltung.second-hand-app.de/public/api/";
String appPassword="!=§§asdiofjdsaklfjmvaoie!!!???34";
