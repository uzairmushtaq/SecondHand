import 'package:flutter/material.dart';

const kLightYellow = Color(0xFFfff7e1);
const kPrimaryColor = Color(0xFFFFBA00);
const kSecondaryColor = Color(0xFF4C7D82);
const kWhiteColor = Color(0xFFF8FAFC);
const kTextColor = Color(0xFF445D5F);
const klightGreen=Color(0xFF4c7d82);
const kLightGrey=Color(0xFFCBD5E1);
const klightGreyText=Color(0xFFE2E8F0);
const kRedColor=Color(0xFFDC2626);