enum ShuffleType{
  liked,
  shuffled,
  byCategory,
  search
}
 